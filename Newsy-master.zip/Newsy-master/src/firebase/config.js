const firebaseConfig = {
  apiKey: "AIzaSyDwtP49aN5kJysw9WR-EJ44szx5qx3_fxw",
  authDomain: "newsy-4f92b.firebaseapp.com",
  databaseURL: "https://newsy-4f92b.firebaseio.com",
  projectId: "newsy-4f92b",
  storageBucket: "newsy-4f92b.appspot.com",
  messagingSenderId: "95207023692",
  appId: "1:95207023692:web:b9cbcf59178393f27600e9",
};

export default firebaseConfig;
